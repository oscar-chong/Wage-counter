//
//  WageWidgetProvider.kt
//  WageTicker Android AppWidget
//
//  Created for Android 10, 11, 12, 13, 14 & 15
//  Runs 100% Offline & Locally via SharedPreferences
//

package com.wageticker.android

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

class WageWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TOILET_LOG = "com.wageticker.ACTION_TOILET_LOG"
        const val ACTION_OVERTIME_TOGGLE = "com.wageticker.ACTION_OVERTIME_TOGGLE"

        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs = context.getSharedPreferences("wageticker_prefs", Context.MODE_PRIVATE)
            val hourlyRate = prefs.getFloat("hourlyRate", 48f).toDouble()
            val currency = prefs.getString("currency", "USD") ?: "$"
            val isUnemployed = prefs.getBoolean("is_unemployed", false)
            val showUnpaidOT = prefs.getBoolean("show_unpaid_ot", false)

            val views = RemoteViews(context.packageName, R.layout.widget_layout)

            if (isUnemployed) {
                views.setTextViewText(R.id.widget_title, "UNEMPLOYED GAP")
                views.setTextViewText(R.id.widget_amount, "$0.00")
                views.setTextColor(R.id.widget_amount, 0xFF94A3B8.toInt())
                views.setTextViewText(R.id.widget_rate, "👔 $0 earnings · Excluded from work schedule")
            } else if (showUnpaidOT) {
                val lostAmount = 1.5 * hourlyRate * 1.5
                views.setTextViewText(R.id.widget_title, "LOST INCOME (UNPAID OT)")
                views.setTextViewText(R.id.widget_amount, "-$$currency${String.format("%.2f", lostAmount)}")
                views.setTextColor(R.id.widget_amount, 0xFFF43F5E.toInt())
                views.setTextViewText(R.id.widget_rate, "⚠️ Unpaid overtime debt owed")
            } else {
                val earned = calculateTodayEarnings(hourlyRate)
                views.setTextViewText(R.id.widget_title, "TODAY'S EARNINGS (OFFLINE)")
                views.setTextViewText(R.id.widget_amount, "$currency${String.format("%.2f", earned)}")
                views.setTextColor(R.id.widget_amount, 0xFF10B981.toInt())
                views.setTextViewText(R.id.widget_rate, "⚡ Rate: $currency${String.format("%.2f", hourlyRate)}/hr")
            }

            // Pending Intent for Toilet Break
            val toiletIntent = Intent(context, WageWidgetProvider::class.java).apply {
                action = ACTION_TOILET_LOG
            }
            val toiletPending = PendingIntent.getBroadcast(
                context, 101, toiletIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.btn_toilet, toiletPending)

            // Pending Intent for Overtime Toggle
            val otIntent = Intent(context, WageWidgetProvider::class.java).apply {
                action = ACTION_OVERTIME_TOGGLE
            }
            val otPending = PendingIntent.getBroadcast(
                context, 102, otIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.btn_overtime, otPending)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun calculateTodayEarnings(hourlyRate: Double): Double {
            val cal = Calendar.getInstance()
            val day = cal.get(Calendar.DAY_OF_WEEK)
            if (day == Calendar.SUNDAY || day == Calendar.SATURDAY) return 0.0

            val hour = cal.get(Calendar.HOUR_OF_DAY)
            val minute = cal.get(Calendar.MINUTE)
            val second = cal.get(Calendar.SECOND)
            val currentHours = hour + (minute / 60.0) + (second / 3600.0)

            val workStart = 9.0
            val workEnd = 17.0

            return when {
                currentHours < workStart -> 0.0
                currentHours >= workEnd -> maxOf(0.0, (workEnd - workStart - 1.0) * hourlyRate)
                else -> maxOf(0.0, (currentHours - workStart) * hourlyRate)
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val prefs = context.getSharedPreferences("wageticker_prefs", Context.MODE_PRIVATE)

        when (intent.action) {
            ACTION_TOILET_LOG -> {
                prefs.edit().putLong("last_toilet_timestamp", System.currentTimeMillis()).apply()
                triggerWidgetUpdate(context)
            }
            ACTION_OVERTIME_TOGGLE -> {
                val current = prefs.getBoolean("show_unpaid_ot", false)
                prefs.edit().putBoolean("show_unpaid_ot", !current).apply()
                triggerWidgetUpdate(context)
            }
        }
    }

    private fun triggerWidgetUpdate(context: Context) {
        val appWidgetManager = AppWidgetManager.getInstance(context)
        val component = ComponentName(context, WageWidgetProvider::class.java)
        val ids = appWidgetManager.getAppWidgetIds(component)
        onUpdate(context, appWidgetManager, ids)
    }
}
