//
//  MainActivity.kt
//  WageTicker Android Application
//
//  Runs 100% Offline & Locally with Local WebView + Native Widgets
//

package com.wageticker.android

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Save initial user salary config to SharedPreferences (100% Offline)
        val prefs = getSharedPreferences("wageticker_prefs", Context.MODE_PRIVATE)
        if (!prefs.contains("hourlyRate")) {
            prefs.edit().apply {
                putFloat("hourlyRate", 48f)
                putFloat("monthlySalary", 8320f)
                putFloat("yearlySalary", 99840f)
                putString("currency", "USD")
                putBoolean("is_unemployed", false)
                apply()
            }
        }

        // Initialize embedded offline local WebView
        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        // Load bundled 100% offline local HTML
        webView.loadUrl("file:///android_asset/www/index.html")

        // Trigger widget update so Home Screen widget refreshes
        updateHomeScreenWidgets()
    }

    private fun updateHomeScreenWidgets() {
        val appWidgetManager = AppWidgetManager.getInstance(this)
        val component = ComponentName(this, WageWidgetProvider::class.java)
        val ids = appWidgetManager.getAppWidgetIds(component)
        val updateIntent = Intent(this, WageWidgetProvider::class.java).apply {
            action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        }
        sendBroadcast(updateIntent)
    }
}
