=============================================================================
WAGETICKER ANDROID APK & HOME SCREEN WIDGET GUIDE (100% OFFLINE)
=============================================================================

This package provides the installable "WageTicker.apk" for physical Android phones
(Samsung Galaxy, Google Pixel, Xiaomi, OnePlus, Motorola, OPPO, etc.) and complete
Android Studio source code with AppWidgetProvider.

-----------------------------------------------------------------------------
HOW TO INSTALL WAGETICKER.APK ON ANDROID (JUST LIKE ANY APK):
-----------------------------------------------------------------------------
1. Download "WageTicker.apk" directly on your Android phone (or copy it over).
2. Tap the downloaded file in your browser's download drawer or Files app.
3. If Android prompts: "For your security, your phone is not allowed to install
   unknown apps from this source":
   -> Tap "Settings"
   -> Turn on "Allow from this source"
4. Tap "Install".
5. WageTicker installs immediately as a native app on your phone!

-----------------------------------------------------------------------------
HOW TO ADD THE WIDGET TO YOUR ANDROID HOME SCREEN:
-----------------------------------------------------------------------------
1. Go to your Android Home Screen.
2. Touch and hold (long press) any empty space on your Home Screen.
3. Tap "Widgets" (or the Widgets icon).
4. Scroll down or search for "WageTicker".
5. Touch and hold the "WageTicker Live Widget" (2x2 or 4x2 size).
6. Drag it to your desired spot on your Home Screen and release!
7. Adjust the widget bounding box to resize if desired.

Your real-time earnings widget is now live on your Android Home Screen, ticking
locally and completely offline with zero internet needed!
=============================================================================
